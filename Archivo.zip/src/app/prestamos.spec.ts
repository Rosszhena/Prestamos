import { Prestamos } from './prestamos';

describe('Prestamos', () => {
  it('should create an instance', () => {
    expect(new Prestamos()).toBeTruthy();
  });
});
