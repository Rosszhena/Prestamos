export class Prestamos {
}
