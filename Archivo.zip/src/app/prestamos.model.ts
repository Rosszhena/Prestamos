export class Prestamos {
  id:string;
  usuario:string;
  valorSolicitado:number;
  fechaPago:string;
  estatus:string
}
